package io.github.paulooorg.template;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemplateMsApplicationTests {

	@Test
	void contextLoads() {
	}

}

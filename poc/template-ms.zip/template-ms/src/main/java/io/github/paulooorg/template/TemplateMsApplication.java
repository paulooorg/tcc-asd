package io.github.paulooorg.template;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemplateMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TemplateMsApplication.class, args);
	}

}
